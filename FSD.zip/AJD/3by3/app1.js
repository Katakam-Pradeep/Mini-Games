const winnerImage = document.getElementById('winner-image');
        if (winner === 'Player 1')
        {
            winnerImage.style.backgroundImage = "url('boy.jpg')";
        }
        else if (winner === 'Player 2')
        {
            winnerImage.style.backgroundImage = "url('girl.jpg')"; 
        }