const cells = document.querySelectorAll(".cells span");
const scoreX = document.querySelector(".player1");
const scoreO = document.querySelector(".player2");
const button = document.querySelector("button");
const submitButton = document.getElementById("submit");

const checkWin = () => {
    const winCombinations = [
        [0, 1, 2, 3], [4, 5, 6, 7], [8, 9, 10, 11], [12, 13, 14, 15],
        [0, 4, 8, 12], [1, 5, 9, 13], [2, 6, 10, 14], [3, 7, 11, 15],
        [0, 5, 10, 15], [3, 6, 9, 12]
    ];

    for (const combo of winCombinations) {
        const [a, b, c, d] = combo;
        if (cells[a].innerHTML &&
            cells[a].innerHTML === cells[b].innerHTML &&
            cells[a].innerHTML === cells[c].innerHTML &&
            cells[a].innerHTML === cells[d].innerHTML) {
            gameActive = false;
            combo.forEach(i => cells[i].style.backgroundColor = "#f37740");
            setTimeout(() => {
                alert(`Player ${currentPlayer} Won!`);
            }, 5);
            updateScores();
            return true;
        }
    }

    if ([...cells].every(cell => cell.innerHTML !== "")) {
        gameActive = false;
        setTimeout(() => {
            alert("It's a Tie!");
        }, 5);
        return true;
    }

    return false;
}

const clickCell = (cell) => {
    if (!gameActive || cell.innerHTML !== "") {
        return;
    }
    cell.innerHTML = currentPlayer;
    cell.style.fontWeight = "bold";
    if (checkWin()) {
        return;
    }
    currentPlayer = currentPlayer === 'S' ? 'O' : 'S';
}

const clearBox = () => {
    cells.forEach(cell => {
        cell.innerHTML = "";
        cell.style.backgroundColor = "transparent";
    });
    gameActive = true;
    currentPlayer = 'S';
}

const updateScores = () => {
    if (currentPlayer == "S") {
        player1++;
        scoreX.innerHTML = "Player S: " + player1;
    } else {
        player2++;
        scoreO.innerHTML = "Player O: " + player2;
    }
}

let currentPlayer = 'S';
let gameActive = true;
let player1 = 0, player2 = 0;

cells.forEach(cell => cell.addEventListener('click', () => clickCell(cell)));
button.addEventListener("click", clearBox);

submitButton.addEventListener("click", () => {
    let winner = player1 > player2 ? "Player S" : "Player O";
    let winningScore = Math.max(player1, player2);
    window.location.href = `winning.html?winner=${winner}&score=${winningScore}`;
});
